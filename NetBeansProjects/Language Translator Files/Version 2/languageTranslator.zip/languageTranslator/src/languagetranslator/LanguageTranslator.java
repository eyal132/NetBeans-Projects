/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package languagetranslator;

import java.util.*;
import java.io.*;

/**
 *
 * @author Eyal Blumental Erez
 */
public class LanguageTranslator {

    public static final String[] wordsToTranslateEnglish = {"CIRCLE", "BLUE", "ONE"};

    public static final String[] wordsToTranslateMaori = {"POROHITA", "PURU", "TAHI"};

    public static ArrayList<String> splitWords = new ArrayList<String>(); 

/**
 * this reader method splits up the words in the sentence of whatsThere, it then adds the words into the splitWords arrayList in the for loop, it then calls the method checkTranslate to translate any words that are needing to get translated
 * @param whatsThere 
 */
    public static void Reader(String whatsThere) {

// this is splitting up words from the whatsThere string into individual words to the words[] array
 String words[] = whatsThere.split(" ");

        // clears array of split words
        splitWords.clear();

        // this adds words in the array from the textbox
        for (int i = 0; i < words.length; i++) {

            String word = words[i];

            splitWords.add(word);
            
        }

        checkTranslate();

    }

    /**
     * this goes through a for loop to make sure that the pointer doesn't go outside the arrays slots which is a fail sage to prevent the application from crashing, the if statements are checking if a word needs to be translated in the sentence, if so it goes into a while loop to check exactly which word it is using the pointer.
     */
    public static void checkTranslate() {

        // this selects a positioin in the array to help translate the word
        int pointer = 0;

        // this tells the while loop to stop looping when the translated word is found
        boolean foundWord = false;

        for (int i = 0; i < splitWords.size(); i++) {

            if (Arrays.asList(wordsToTranslateEnglish).contains(splitWords.get(i).toUpperCase())) {

                while (wordsToTranslateEnglish.length > pointer && foundWord == false) {

                    if (!wordsToTranslateEnglish[pointer].equals(splitWords.get(i).toUpperCase())) {

                        pointer++;

                    } else {

                        foundWord = true;

                    }
                }

                splitWords.set(i , wordsToTranslateMaori[pointer]);

                System.out.println(splitWords.get(i));

            } else if (Arrays.asList(wordsToTranslateMaori).contains(splitWords.get(i).toUpperCase())) {

                while (wordsToTranslateEnglish.length > pointer && foundWord == false) {

                    if (!wordsToTranslateEnglish[pointer].equals(splitWords.get(i).toUpperCase())) {

                        pointer++;

                    } else {

                        foundWord = true;

                    }
                }

                splitWords.set(i, wordsToTranslateEnglish[pointer]);

                System.out.println(splitWords.get(i));

            } else {

                System.out.println(splitWords.get(i));

            }

        }

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GUI UI = new GUI();
        UI.setVisible(true);
    }

}
