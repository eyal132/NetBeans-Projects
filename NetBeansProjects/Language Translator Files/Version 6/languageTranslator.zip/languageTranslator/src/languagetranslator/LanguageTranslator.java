/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package languagetranslator;

//This imports the packages that we need for arrayLists and readers etc.
import java.util.*;
import java.io.*;

/**
 *
 * @author Eyal Blumental Erez
 */
public class LanguageTranslator {

    public static int languagePointer = 0;

    //This arrayList is created to keep all the split words for translation and printing
    public static ArrayList<String> splitWords = new ArrayList<String>();

    //This changes to which radio button is pressed so that the code knows which language to translate from.
    public static String languageOption = "ENGLISH";

    //This array has punctuation which is used to make sure that it doesn't affect translation when it is seen in text, array used in GUI.java.
    public static final String[] punctuation = {".", ",", "!", "?", ";", ":"};

    //This creates a new 2d array to store all the words that the code will look for to translate
    public static String wordsToCheck[][] = new String[36][2];

    public static String[][] extraWords = new String[9][5];

    /**
     * this reader method splits up the words in the sentence of whatsThere, it
     * then adds the words into the splitWords arrayList in the for loop, it
     * then calls the method checkTranslate to translate any words that are
     * needing to get translated
     *
     * @param whatsThere
     */
    public static void Reader(String whatsThere) {

        wordsToAdd();

// this is splitting up words from the whatsThere string into individual words to the words[] array
        String words[] = whatsThere.split(" |(?=\\.)|(?=\\,)|(?=\\!)|(?=\\?)|(?=\\;)|(?=\\:)");

        // clears array of split words
        splitWords.clear();

        // this adds words in the array from the textbox
        for (int i = 0; i < words.length; i++) {

            String word = words[i];

            splitWords.add(word);
            System.out.println(word);
        }
        splitWords.add(" ");
        splitWords.add(" ");
        splitWords.add(" ");

        Translate();

    }

    /**
     * This method is creating all the words needed in the 2d array in order to
     * be able to recognize them for translation
     */
    public static void wordsToAdd() {

        wordsToCheck[0][0] = "ONE";
        wordsToCheck[1][0] = "TWO";
        wordsToCheck[2][0] = "THREE";
        wordsToCheck[3][0] = "FOUR";
        wordsToCheck[4][0] = "FIVE";
        wordsToCheck[5][0] = "CIRCLE";
        wordsToCheck[6][0] = "SQUARE";
        wordsToCheck[7][0] = "RECTANGLE";
        wordsToCheck[8][0] = "BLUE";
        wordsToCheck[9][0] = "GREEN";
        wordsToCheck[10][0] = "YELLOW";
        wordsToCheck[11][0] = "WHITE";
        wordsToCheck[12][0] = "ONE";
        wordsToCheck[13][0] = "CIRClE";
        wordsToCheck[14][0] = "TEN";
        wordsToCheck[15][0] = "SIX";
        wordsToCheck[16][0] = "SEVEN";
        wordsToCheck[17][0] = "EIGHT";
        wordsToCheck[18][0] = "NINE";
        wordsToCheck[19][0] = "TWENTY";
        wordsToCheck[20][0] = "THIRTY";
        wordsToCheck[21][0] = "FOURTY";
        wordsToCheck[22][0] = "FIFTY";
        wordsToCheck[23][0] = "SIXTY";
        wordsToCheck[24][0] = "SEVENTY";
        wordsToCheck[25][0] = "EIGHTY";
        wordsToCheck[26][0] = "NINETY";
        wordsToCheck[27][0] = "ELEVEN";
        wordsToCheck[28][0] = "TWELVE";
        wordsToCheck[29][0] = "THIRTEEN";
        wordsToCheck[30][0] = "FOURTEEN";
        wordsToCheck[31][0] = "FIFTEEN";
        wordsToCheck[32][0] = "SIXTEEN";
        wordsToCheck[33][0] = "SEVENTEEN";
        wordsToCheck[34][0] = "EIGHTEEN";
        wordsToCheck[35][0] = "NINETEEN";
        wordsToCheck[0][1] = "TAHI";
        wordsToCheck[1][1] = "RUA";
        wordsToCheck[2][1] = "TORU";
        wordsToCheck[3][1] = "WHA";
        wordsToCheck[4][1] = "RIMA";
        wordsToCheck[5][1] = "POROHITA";
        wordsToCheck[6][1] = "TAPAWHA";
        wordsToCheck[7][1] = "TAAPIRI";
        wordsToCheck[8][1] = "PURU";
        wordsToCheck[9][1] = "MATOMATO";
        wordsToCheck[10][1] = "KOWHAI";
        wordsToCheck[11][1] = "MA";
        wordsToCheck[12][1] = "KOTAHI";
        wordsToCheck[13][1] = "AWHIO";
        wordsToCheck[14][1] = "TEKAU";
        wordsToCheck[15][1] = "ONO";
        wordsToCheck[16][1] = "WHITU";
        wordsToCheck[17][1] = "WARU";
        wordsToCheck[18][1] = "IWA";
        wordsToCheck[19][1] = "RUA TEKAU";
        wordsToCheck[20][1] = "TORU TEKAU";
        wordsToCheck[21][1] = "WHA TEKAU";
        wordsToCheck[22][1] = "RIMA TEKAU";
        wordsToCheck[23][1] = "ONO TEKAU";
        wordsToCheck[24][1] = "WHITU TEKAU";
        wordsToCheck[25][1] = "WARU TEKAU";
        wordsToCheck[26][1] = "IWA TEKAU";
        wordsToCheck[27][1] = "TEKAU MA TAHI";
        wordsToCheck[28][1] = "TEKAU MA RUA";
        wordsToCheck[29][1] = "TEKAU MA TORU";
        wordsToCheck[30][1] = "TEKAU MA WHA";
        wordsToCheck[31][1] = "TEKAU MA RIMA";
        wordsToCheck[32][1] = "TEKAU MA ONO";
        wordsToCheck[33][1] = "TEKAU MA WHITU";
        wordsToCheck[34][1] = "TEKAU MA WARU";
        wordsToCheck[35][1] = "TEKAU MA IWA";

        extraWords[0][0] = "TEKAU";
        extraWords[1][0] = "RUA";
        extraWords[2][0] = "TORU";
        extraWords[3][0] = "WHA";
        extraWords[4][0] = "RIMA";
        extraWords[5][0] = "ONO";
        extraWords[6][0] = "WHITU";
        extraWords[7][0] = "WARU";
        extraWords[8][0] = "IWA";
        extraWords[0][1] = "TAHI";
        extraWords[1][1] = "RUA";
        extraWords[2][1] = "TORU";
        extraWords[3][1] = "WHA";
        extraWords[4][1] = "RIMA";
        extraWords[5][1] = "ONO";
        extraWords[6][1] = "WHITU";
        extraWords[7][1] = "WARU";
        extraWords[8][1] = "IWA";
        extraWords[0][2] = "ELEVEN";
        extraWords[1][2] = "TWELVE";
        extraWords[2][2] = "THIRTEEN";
        extraWords[3][2] = "FOURTEEN";
        extraWords[4][2] = "FIFTEEN";
        extraWords[5][2] = "SIXTEEN";
        extraWords[6][2] = "SEVENTEEN";
        extraWords[7][2] = "EIGHTEEN";
        extraWords[8][2] = "NINETEEN";
        extraWords[0][3] = "TWENTY";
        extraWords[1][3] = "THIRTY";
        extraWords[2][3] = "FOURTY";
        extraWords[3][3] = "FIFTY";
        extraWords[4][3] = "SIXTY";
        extraWords[5][3] = "SEVENTY";
        extraWords[6][3] = "EIGHTY";
        extraWords[7][3] = "NINETY";
        extraWords[8][3] = " ";
        extraWords[0][4] = "ONE";
        extraWords[1][4] = "TWO";
        extraWords[2][4] = "THREE";
        extraWords[3][4] = "FOUR";
        extraWords[4][4] = "FIVE";
        extraWords[5][4] = "SIX";
        extraWords[6][4] = "SEVEN";
        extraWords[7][4] = "EIGHT";
        extraWords[8][4] = "NINE";

    }

    /**
     * This goes through an algorithm that checks if a words needs to be
     * translated and exactly which word needs to be swapped out. It then takes
     * the opposing array and swaps out the word in the splitWords array in
     * order to translate. If it is a number it goes through a seperate
     * algorithm which looks at another 2d array which has different numbers in
     * different places in order to translate numbers up to 99.
     */
    public static void Translate() {

        /**
         * this checks which radio button has been chosen, in this case if it is
         * English it goes through this part of the translator
         */
        if (languageOption.equals("ENGLISH")) {

            languagePointer = 0;

        } else if (languageOption.equals("MAORI")) {

            languagePointer = 1;

        }

        // this selects a positioin in the array to help translate the word
        int pointer = 0;

        int wordPointer = 0;

        // this tells the checkTranslate while loop to stop looping when the translated word is found
        boolean foundWord = false;

        /**
         * This for loop is a calculated algorithm that goes through all the
         * split words and checks if they need to be translated or not, before
         * being translated it checks if the word is a number and if so it goes
         * through another series of for loops this allows the algorithm to
         * apply up to 99 numbers in both English and Maori while not affecting
         * the other words in the array. Every for loop in the algorithm is
         * either to find where a word is in a 2d array or which language it
         * needs to be in, in order to translate the word.
         */
        for (int i = 0; i < splitWords.size(); i++) {

            foundWord = false;

            for (wordPointer = 0; wordPointer < (wordsToCheck.length); wordPointer++) {

                if (Arrays.asList(wordsToCheck[wordPointer][languagePointer]).contains(splitWords.get(i).toUpperCase())) {

                    pointer = 0;

                    while (wordsToCheck.length > pointer && foundWord == false) {

                        if (!wordsToCheck[pointer][languagePointer].equals(splitWords.get(i).toUpperCase())) {

                            pointer++;

                        } else {

                            foundWord = true;

                        }
                    }

                    int extraWordPointer = 0;

                    boolean extraFoundWord = false;

                    int languageChecker = 0;

                    boolean wordChecker = false;

                    int secondLanguagePointer = 0;

                    secondLanguagePointer = languagePointer;

                    for (int b = 0; b < extraWords.length; b++) {

                        if (extraWords[b][languageChecker].contains(wordsToCheck[pointer][languagePointer])) {

                            wordChecker = true;

                            b = extraWords.length;

                        } else if (b == extraWords.length - 1 && languageChecker < 3) {

                            languageChecker++;

                            b = -1;

                        } else if (b == extraWords.length - 1 && languageChecker <= 4) {

                            if (secondLanguagePointer == 0) {

                                secondLanguagePointer = 1;

                            } else if (secondLanguagePointer == 1) {

                                secondLanguagePointer = 0;

                            }

                            splitWords.set(i, wordsToCheck[pointer][secondLanguagePointer].toLowerCase());

                            b = extraWords.length;

                        }

                    }

                    if (languagePointer == 1 && wordChecker == true) {

                        extraWordPointer = 0;

                        extraFoundWord = false;

                        for (int p = 0; p < extraWords.length - 1; p++) {

                            if (wordsToCheck[pointer][1].toUpperCase().contains(extraWords[p][extraWordPointer].toUpperCase()) && extraFoundWord == false) {

                                if (extraWordPointer == 0) {

                                    extraWordPointer = 1;
                                }

                                for (int q = 0; q < extraWords.length; q++) {

                                    try {

                                        if (p == 0 && splitWords.get(i + 1).toUpperCase().equals("TEKAU")) {

                                        } else {

                                            if (!splitWords.get(i + 2).equals("") || !splitWords.get(i + 3).equals("")) {

                                                if (splitWords.get(i + 3).toUpperCase().contains(extraWords[q][extraWordPointer].toUpperCase()) || splitWords.get(i + 2).toUpperCase().contains(extraWords[q][extraWordPointer].toUpperCase())) {

                                                    if ((splitWords.get(i + 2)).equals("ma") && p > 0) {

                                                        splitWords.set(i, extraWords[p - 1][3].toLowerCase() + " " + extraWords[q][4].toLowerCase());

                                                        splitWords.remove(i + 3);

                                                        splitWords.remove(i + 2);

                                                        splitWords.remove(i + 1);

                                                        q = extraWords.length;

                                                        extraFoundWord = true;

                                                    } else if ((splitWords.get(i + 1)).equals("ma")) {

                                                        splitWords.set(i, extraWords[q][2].toLowerCase());

                                                        System.out.println(splitWords.get(i));

                                                        splitWords.remove(i + 1);

                                                        splitWords.remove(i + 2);

                                                        q = extraWords.length - 1;

                                                        extraFoundWord = true;

                                                    }

                                                }
                                            }
                                        }

                                    } catch (IndexOutOfBoundsException ex) {

                                        System.out.println("Error!");

                                    }

                                    if (q == extraWords.length - 1 && extraFoundWord == false) {

                                        splitWords.set(i, wordsToCheck[pointer][0].toLowerCase());

                                        extraFoundWord = true;

                                    }

                                }

                            }

                        }

                    } else if (wordChecker == true) {

                        for (int p = 0; p < extraWords.length - 2; p++) {

                            extraWordPointer = 2;

                            extraFoundWord = false;

                            if (wordsToCheck[pointer][0].toUpperCase().contains(extraWords[p][extraWordPointer + 1].toUpperCase()) && extraFoundWord == false) {

                                if (extraWordPointer == 2) {

                                    extraWordPointer = 1;

                                }

                                for (int q = 0; q < extraWords.length; q++) {

                                    try {
                                        if (splitWords.get(i + 1).toUpperCase().contains(extraWords[q][4].toUpperCase())) {

                                            splitWords.set(i, extraWords[p + 1][0].toLowerCase() + " tekau ma " + extraWords[q][1].toLowerCase());

                                            extraFoundWord = true;

                                            splitWords.remove(i + 1);

                                            q = extraWords.length;

                                            p = extraWords.length;

                                        }
                                    } catch (IndexOutOfBoundsException ex) {

                                        System.out.println("Error!");

                                    }

                                }

                            } else if (p == extraWords.length - 3) {

                                splitWords.set(i, wordsToCheck[pointer][1].toLowerCase());

                                pointer = 0;

                                wordPointer = wordsToCheck.length + 1;

                            }

                        }

                    }

                }

            }

        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GUI UI = new GUI();
        UI.setVisible(true);
    }

}
