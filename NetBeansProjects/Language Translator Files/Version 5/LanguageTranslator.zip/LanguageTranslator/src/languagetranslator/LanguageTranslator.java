/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package languagetranslator;

//This imports the packages that we need for arrayLists and readers etc.
import java.util.*;
import java.io.*;

/**
 *
 * @author Eyal Blumental Erez
 */
public class LanguageTranslator {

    public static int languagePointer = 0;

    //This arrayList is created to keep all the split words for translation and printing
    public static ArrayList<String> splitWords = new ArrayList<String>();

    //This changes to which radio button is pressed so that the code knows which language to translate from.
    public static String languageOption = "ENGLISH";

    //This array has punctuation which is used to make sure that it doesn't affect translation when it is seen in text, array used in GUI.java.
    public static final String[] punctuation = {".", ",", "!", "?", ";", ":"};

    //This creates a new 2d array to store all the words that the code will look for to translate
    public static String wordsToCheck[][] = new String[14][2];

    /**
     * this reader method splits up the words in the sentence of whatsThere, it
     * then adds the words into the splitWords arrayList in the for loop, it
     * then calls the method checkTranslate to translate any words that are
     * needing to get translated
     *
     * @param whatsThere
     */
    public static void Reader(String whatsThere) {

        wordsToCheck();

// this is splitting up words from the whatsThere string into individual words to the words[] array
        String words[] = whatsThere.split(" |(?=\\.)|(?=\\,)|(?=\\!)|(?=\\?)|(?=\\;)|(?=\\:)");

        // clears array of split words
        splitWords.clear();

        // this adds words in the array from the textbox
        for (int i = 0; i < words.length; i++) {

            String word = words[i];

            splitWords.add(word);
            System.out.println(word);
        }

        Translate();

    }

    /**
     * This method is creating all the words needed in the 2d array in order to
     * be able to recognize them for translation
     */
    public static void wordsToCheck() {

        wordsToCheck[0][0] = "ONE";
        wordsToCheck[1][0] = "TWO";
        wordsToCheck[2][0] = "THREE";
        wordsToCheck[3][0] = "FOUR";
        wordsToCheck[4][0] = "FIVE";
        wordsToCheck[5][0] = "CIRCLE";
        wordsToCheck[6][0] = "SQUARE";
        wordsToCheck[7][0] = "RECTANGLE";
        wordsToCheck[8][0] = "BLUE";
        wordsToCheck[9][0] = "GREEN";
        wordsToCheck[10][0] = "YELLOW";
        wordsToCheck[11][0] = "WHITE";
        wordsToCheck[12][0] = "ONE";
        wordsToCheck[13][0] = "CIRClE";
        wordsToCheck[0][1] = "TAHI";
        wordsToCheck[1][1] = "RUA";
        wordsToCheck[2][1] = "TORU";
        wordsToCheck[3][1] = "WHA";
        wordsToCheck[4][1] = "RIMA";
        wordsToCheck[5][1] = "POROHITA";
        wordsToCheck[6][1] = "TAPAWHA";
        wordsToCheck[7][1] = "TAAPIRI";
        wordsToCheck[8][1] = "PURU";
        wordsToCheck[9][1] = "MATOMATO";
        wordsToCheck[10][1] = "KOWHAI";
        wordsToCheck[11][1] = "MA";
        wordsToCheck[12][1] = "KOTAHI";
        wordsToCheck[13][1] = "AWHIO";

    }

    /**
     * This goes through an algorithm that checks if a words needs to be
     * translated and exactly which word needs to be swapped out. It then takes
     * the opposing array and swaps out the word in the splitWords array in
     * order to translate.
     */
    public static void Translate() {

        /**
         * this checks which radio button has been chosen, in this case if it is
         * English it goes through this part of the translator
         */
        if (languageOption.equals("ENGLISH")) {

            languagePointer = 0;

        } else if (languageOption.equals("MAORI")) {

            languagePointer = 1;


        }

        // this selects a positioin in the array to help translate the word
        int pointer = 0;

        int wordPointer = 0;

        // this tells the checkTranslate while loop to stop looping when the translated word is found
        boolean foundWordMaori = false;

        /**
         * this for loop goes through all the words in the splitWords array to
         * check which words need to be translated or not. it uses an algorithm
         * using the 2d array to check which words need to be translated.
         */
        for (int i = 0; i < splitWords.size(); i++) {

            foundWordMaori = false;

            for (wordPointer = 0; wordPointer < (wordsToCheck.length); wordPointer++) {

                if (Arrays.asList(wordsToCheck[wordPointer][languagePointer]).contains(splitWords.get(i).toUpperCase())) {

                    while (wordsToCheck.length > pointer && foundWordMaori == false) {

                        if (!wordsToCheck[pointer][languagePointer].equals(splitWords.get(i).toUpperCase())) {

                            pointer++;

                        } else {

                            foundWordMaori = true;

                        }
                    }

                    if (languagePointer == 1) {

                        splitWords.set(i, wordsToCheck[pointer][0].toLowerCase());

                        pointer = 0;

                        wordPointer = wordsToCheck.length + 1;

                    } else {

                        splitWords.set(i, wordsToCheck[pointer][1].toLowerCase());

                        pointer = 0;

                        wordPointer = wordsToCheck.length + 1;

                    }

                }

            }

        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GUI UI = new GUI();
        UI.setVisible(true);
    }

}
